# EduGenie: Gemini-Powered Learning Assistant

Q&A, concept explanations, quizzes, summaries and learning paths in a small FastAPI app.

## Setup
1. Install Python 3.10+ and create a virtual environment:
   `python -m venv venv` then `source venv/bin/activate` (Windows: `venv\Scripts\activate`)
2. `pip install -r requirements.txt`
   (Skip `transformers`, `torch`, `sentencepiece` if you don't want the local model; explanations then use Gemini.)
3. Get a key from Google AI Studio, then `cp .env.example .env` and paste it in.
4. `uvicorn main:app --reload` and open http://127.0.0.1:8000

The first "Explain" request downloads LaMini-Flan-T5-783M (about 3 GB), so it is slow once.

## Endpoints (POST, body `{"text": "..."}`)
`/qa`, `/explain`, `/quiz`, `/summarize`, `/learn/recommendations`
