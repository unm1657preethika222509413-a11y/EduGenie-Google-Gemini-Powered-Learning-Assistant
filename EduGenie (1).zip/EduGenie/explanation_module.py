"""Concept explanation using the local LaMini-Flan-T5-783M model.

If `transformers`/`torch` are not installed, falls back to Gemini so the app still works.
"""
from gemini_client import ask_gemini

MODEL_NAME = "MBZUAI/LaMini-Flan-T5-783M"
_pipe = None


def _load_pipeline():
    global _pipe
    if _pipe is None:
        from transformers import pipeline
        _pipe = pipeline("text2text-generation", model=MODEL_NAME)
    return _pipe


def explain_concept(topic: str) -> str:
    prompt = f"Explain the following concept in simple words for a beginner: {topic}"
    try:
        result = _load_pipeline()(prompt, max_new_tokens=256, do_sample=False)
        return result[0]["generated_text"].strip()
    except ImportError:
        return ask_gemini(prompt + "\nUse plain text and short sentences, with one everyday example.")
