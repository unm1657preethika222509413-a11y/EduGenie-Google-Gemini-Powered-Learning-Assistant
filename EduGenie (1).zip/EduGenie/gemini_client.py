"""Shared helper for calling the Gemini API."""
import os

from dotenv import load_dotenv
from google import genai

load_dotenv()
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
_client = None


def ask_gemini(prompt: str) -> str:
    global _client
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        raise RuntimeError("GEMINI_API_KEY is not set. Copy .env.example to .env and add your key.")
    if _client is None:
        _client = genai.Client(api_key=key)
    response = _client.models.generate_content(model=MODEL, contents=prompt)
    if not response.text:
        raise RuntimeError("Gemini returned an empty response. Try rephrasing your input.")
    return response.text.strip()
