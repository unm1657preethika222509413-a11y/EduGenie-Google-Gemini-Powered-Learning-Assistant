"""Personalized learning paths with Gemini."""
from gemini_client import ask_gemini


def get_learning_recommendations(topic: str) -> str:
    prompt = (
        f"Create a structured learning path for: {topic}.\n"
        "Organize it into Beginner, Intermediate and Advanced stages. For each stage give the "
        "key concepts, a rough timeline, and useful resources (videos, articles or books). "
        "Use plain text with simple headings and dashes, no Markdown symbols like ** or #."
    )
    return ask_gemini(prompt)
