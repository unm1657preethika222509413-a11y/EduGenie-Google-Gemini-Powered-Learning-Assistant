"""EduGenie: FastAPI app. Run with:  uvicorn main:app --reload"""
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

from explanation_module import explain_concept
from learning_path import get_learning_recommendations
from qna import answer_question
from quiz_module import generate_quiz
from summary_module import summarize_text

app = FastAPI(title="EduGenie")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


class TextIn(BaseModel):
    text: str


def run(fn, payload: TextIn):
    text = payload.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Please enter some text first.")
    try:
        return fn(text)
    except Exception as err:
        raise HTTPException(status_code=502, detail=str(err))


@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(request, "index.html")


@app.post("/qa")
def qa(payload: TextIn):
    return {"result": run(answer_question, payload)}


@app.post("/explain")
def explain(payload: TextIn):
    return {"result": run(explain_concept, payload)}


@app.post("/quiz")
def quiz(payload: TextIn):
    return {"result": run(generate_quiz, payload)}


@app.post("/summarize")
def summarize(payload: TextIn):
    return {"result": run(summarize_text, payload)}


@app.post("/learn/recommendations")
def recommendations(payload: TextIn):
    return {"result": run(get_learning_recommendations, payload)}
