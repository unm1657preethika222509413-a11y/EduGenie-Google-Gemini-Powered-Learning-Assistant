"""Question answering with Gemini."""
from gemini_client import ask_gemini


def answer_question(question: str) -> str:
    prompt = (
        "You are EduGenie, a helpful tutor. Answer the student's question accurately "
        "and concisely in plain text (no Markdown symbols).\n\n"
        f"Question: {question}"
    )
    return ask_gemini(prompt)
