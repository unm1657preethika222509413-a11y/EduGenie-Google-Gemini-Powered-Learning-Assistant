"""Quiz generation: 3 multiple-choice questions, 4 options each, returned as JSON."""
import json
import re

from gemini_client import ask_gemini


def clean_json_block(text: str) -> str:
    """Strip Markdown code fences (```json ... ```) around a JSON reply."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def generate_quiz(passage: str) -> list:
    prompt = (
        "Create exactly 3 multiple-choice questions from the topic or passage below. "
        "Each question needs exactly 4 plausible options. "
        "Reply with ONLY a JSON array, no other text, in this format:\n"
        '[{"question": "...", "options": ["A", "B", "C", "D"], "answer": "<must match one option exactly>"}]\n\n'
        f"Topic or passage:\n{passage}"
    )
    raw = ask_gemini(prompt)
    try:
        quiz = json.loads(clean_json_block(raw))
        for q in quiz:
            if len(q["options"]) != 4 or q["answer"] not in q["options"]:
                raise ValueError("a question has the wrong number of options or a missing answer")
        return quiz
    except (json.JSONDecodeError, KeyError, TypeError, ValueError) as err:
        raise RuntimeError(f"Could not parse the quiz ({err}). Raw model output: {raw[:300]}")
