"""Summarization with Gemini."""
from gemini_client import ask_gemini


def summarize_text(text: str) -> str:
    prompt = (
        "Summarize the passage below for quick revision. Keep the key facts, remove repetition, "
        "and use 3 to 5 short sentences in plain text.\n\n"
        f"Passage:\n{text}"
    )
    return ask_gemini(prompt)
